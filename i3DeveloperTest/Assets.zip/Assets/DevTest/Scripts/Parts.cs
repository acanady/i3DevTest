﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//Class containing the selectable parts for an object, parts set in inspector
public class Parts : MonoBehaviour
{

    public List<GameObject> selectable_parts;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
